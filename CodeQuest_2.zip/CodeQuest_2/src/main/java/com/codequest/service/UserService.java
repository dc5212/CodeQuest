package com.codequest.service;

import com.codequest.dao.UserDAO;
import com.codequest.model.User;

import java.sql.SQLException;
import java.util.Optional;

public class UserService {
    private final UserDAO userDAO;

    public UserService() {
        this.userDAO = new UserDAO();
    }

    public Optional<User> authenticate(String username, String password) throws SQLException {
        return userDAO.findByUsername(username)
                .filter(user -> user.getPassword().equals(password));
    }

    public User createUser(String username, String password) throws SQLException {
        return userDAO.createUser(username, password);
    }

    public void updateSolvedCount(int userId) throws SQLException {
        userDAO.incrementSolvedCount(userId);
    }

    public User getUserById(int userId) throws SQLException {
        return userDAO.findById(userId)
                .orElseThrow(() -> new SQLException("User not found"));
    }
}