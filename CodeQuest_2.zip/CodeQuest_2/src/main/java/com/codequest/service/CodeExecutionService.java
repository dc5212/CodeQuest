
package com.codequest.service;

import com.codequest.model.TestCase;
import com.codequest.model.TestResult;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CodeExecutionService {
    private static final String TEMP_DIR = System.getProperty("java.io.tmpdir");
    private static final long TIMEOUT_SECONDS = 5;

    private static class ParsedInput {
        Map<String, String> params = new HashMap<>();
        String methodName;
    }

    private ParsedInput parseInput(String input, String code) {
        ParsedInput result = new ParsedInput();
        
        // If input is array format, handle it specially
        if (input.trim().startsWith("[")) {
            result.params.put("arr", input.trim());
            // Try to find method name from code
            Pattern methodPattern = Pattern.compile("public\\s+\\w+\\s+(\\w+)\\s*\\(");
            Matcher methodMatcher = methodPattern.matcher(code);
            if (methodMatcher.find()) {
                result.methodName = methodMatcher.group(1);
            }
            return result;
        }

        // Parse regular input format like "n = 5" or "num = "1234""
        String[] pairs = input.split(",");
        for (String pair : pairs) {
            String[] parts = pair.trim().split("=");
            if (parts.length == 2) {
                String paramName = parts[0].trim();
                String paramValue = parts[1].trim();
                result.params.put(paramName, paramValue);
            }
        }

        // Find method name from code
        Pattern methodPattern = Pattern.compile("public\\s+\\w+\\s+(\\w+)\\s*\\(");
        Matcher methodMatcher = methodPattern.matcher(code);
        if (methodMatcher.find()) {
            result.methodName = methodMatcher.group(1);
        }

        return result;
    }

    private String createMainMethod(String code, ParsedInput parsedInput) {
        StringBuilder mainMethod = new StringBuilder();
        mainMethod.append("    public static void main(String[] args) {\n");
        mainMethod.append("        Solution solution = new Solution();\n");
        
        // Build the method call
        StringBuilder call = new StringBuilder();
        call.append("        System.out.println(solution.").append(parsedInput.methodName).append("(");

        // Handle array parameters
        List<String> paramValues = new ArrayList<>();
        for (Map.Entry<String, String> entry : parsedInput.params.entrySet()) {
            String value = entry.getValue();
            if (value.startsWith("[") && value.endsWith("]")) {
                // Convert string array representation to Java array
                value = "new int[] " + value;
            }
            paramValues.add(value);
        }
        
        call.append(String.join(", ", paramValues));
        call.append("));");
        
        mainMethod.append(call).append("\n");
        mainMethod.append("    }\n");
        
        return mainMethod.toString();
    }

    private String injectMainMethod(String code, String mainMethod) {
        int lastBrace = code.lastIndexOf("}");
        if (lastBrace == -1) {
            throw new IllegalArgumentException("Invalid code format");
        }
        return code.substring(0, lastBrace) + "\n" + mainMethod + "\n}";
    }

    private String normalizeOutput(String output) {
        if (output == null) return "";
        
        output = output.trim();
        
        // Handle string literals - remove quotes if they match at start and end
        if ((output.startsWith("\"") && output.endsWith("\"")) ||
            (output.startsWith("'") && output.endsWith("'"))) {
            output = output.substring(1, output.length() - 1);
        }
        
        // Handle array output
        if (output.startsWith("[") && output.endsWith("]")) {
            String content = output.substring(1, output.length() - 1);
            String[] elements = content.split("\\s*,\\s*");
            Arrays.sort(elements);
            return "[" + String.join(", ", elements) + "]";
        }
        
        return output;
    }

    private boolean compareOutputs(String expected, String actual) {
        String normalizedExpected = normalizeOutput(expected);
        String normalizedActual = normalizeOutput(actual);
        
        // Handle array comparisons
        if (normalizedExpected.startsWith("[") && normalizedExpected.endsWith("]") &&
            normalizedActual.startsWith("[") && normalizedActual.endsWith("]")) {
            
            Set<String> expectedSet = new HashSet<>(Arrays.asList(
                normalizedExpected.substring(1, normalizedExpected.length() - 1).split("\\s*,\\s*")));
            Set<String> actualSet = new HashSet<>(Arrays.asList(
                normalizedActual.substring(1, normalizedActual.length() - 1).split("\\s*,\\s*")));
            
            return expectedSet.equals(actualSet);
        }
        
        // Handle boolean values
        if (normalizedExpected.equals("true") || normalizedExpected.equals("false")) {
            return normalizedExpected.equals(normalizedActual);
        }
        
        return normalizedExpected.equals(normalizedActual);
    }

    public TestResult executeCode(String code, TestCase testCase) {
        Path tempDir = Paths.get(TEMP_DIR, "codequest_" + System.currentTimeMillis());
        try {
            Files.createDirectories(tempDir);
            
            // Parse input and create Main method
            ParsedInput parsedInput = parseInput(testCase.getInput(), code);
            String mainMethod = createMainMethod(code, parsedInput);
            String completeCode = injectMainMethod(code, mainMethod);
            
            // Write the complete code to file
            Path sourceFile = tempDir.resolve("Solution.java");
            Files.write(sourceFile, completeCode.getBytes());
            
            // Compile
            Process compileProcess = new ProcessBuilder(
                "javac", "-source", "1.8", "-target", "1.8", sourceFile.toString()
            )
            .directory(tempDir.toFile())
            .redirectErrorStream(true)
            .start();
            
            String compileOutput = readProcess(compileProcess);
            if (compileProcess.waitFor() != 0) {
                return new TestResult(false, "", "Compilation error:\n" + compileOutput);
            }
            
            // Run
            Process runProcess = new ProcessBuilder("java", "Solution")
                .directory(tempDir.toFile())
                .redirectErrorStream(true)
                .start();
            
            // Read output with timeout
            ExecutorService executor = Executors.newSingleThreadExecutor();
            Future<String> future = executor.submit(new Callable<String>() {
                @Override
                public String call() throws Exception {
                    return readProcess(runProcess);
                }
            });
            
            try {
                String output = future.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
                String expectedOutput = testCase.getExpectedOutput().trim();
                String actualOutput = output != null ? output.trim() : "";
                
                System.out.println("Input: [" + testCase.getInput() + "]");
                System.out.println("Expected: [" + expectedOutput + "]");
                System.out.println("Got: [" + actualOutput + "]");
                
                boolean passed = compareOutputs(expectedOutput, actualOutput);
                return new TestResult(
                    passed,
                    actualOutput,
                    passed ? "" : "Expected: " + expectedOutput + "\nGot: " + actualOutput
                );
            } catch (TimeoutException e) {
                runProcess.destroyForcibly();
                return new TestResult(false, "", "Execution timed out after " + TIMEOUT_SECONDS + " seconds");
            } finally {
                executor.shutdownNow();
                runProcess.destroyForcibly();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new TestResult(false, "", "Error: " + e.getMessage());
        } finally {
            deleteDirectory(tempDir.toFile());
        }
    }

    private String readProcess(Process process) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }
        return output.toString().trim();
    }

    private void deleteDirectory(File directory) {
        if (directory.exists()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        deleteDirectory(file);
                    } else {
                        file.delete();
                    }
                }
            }
            directory.delete();
        }
    }
}