// src/main/java/com/codequest/service/QuestionService.java
package com.codequest.service;

import com.codequest.config.DatabaseConfig;
import com.codequest.model.Question;
import com.codequest.model.TestCase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuestionService {
    private final DatabaseConfig dbConfig;

    public QuestionService() {
        this.dbConfig = DatabaseConfig.getInstance();
    }

    public List<Question> getAllQuestions() throws SQLException {
        List<Question> questions = new ArrayList<>();
        String sql = "SELECT * FROM questions";

        try (Connection conn = dbConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                questions.add(new Question(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("content"),
                    rs.getString("difficulty"),
                    rs.getString("java_template")
                ));
            }
        }
        return questions;
    }

    public Question getQuestionById(int id) throws SQLException {
        String sql = "SELECT * FROM questions WHERE id = ?";
        
        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Question(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("content"),
                    rs.getString("difficulty"),
                    rs.getString("java_template")
                );
            }
        }
        return null;
    }

    public List<Question> getQuestionsByDifficulty(String difficulty) throws SQLException {
        List<Question> questions = new ArrayList<>();
        String sql = "SELECT * FROM questions WHERE difficulty = ?";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, difficulty);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                questions.add(new Question(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("content"),
                    rs.getString("difficulty"),
                    rs.getString("java_template")
                ));
            }
        }
        return questions;
    }

    public List<TestCase> getTestCasesForQuestion(int questionId) throws SQLException {
        List<TestCase> testCases = new ArrayList<>();
        String sql = "SELECT * FROM test_cases WHERE question_id = ?";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                testCases.add(new TestCase(
                    rs.getInt("id"),
                    rs.getInt("question_id"),
                    rs.getString("input"),
                    rs.getString("expected_output")
                ));
            }
        }
        return testCases;
    }
}