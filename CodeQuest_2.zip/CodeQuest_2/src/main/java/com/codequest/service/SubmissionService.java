
package com.codequest.service;

import com.codequest.dao.SubmissionDAO;
import com.codequest.model.Question;
import com.codequest.model.Submission;
import com.codequest.model.TestCase;
import com.codequest.model.TestResult;
import com.codequest.model.User;

import java.sql.SQLException;
import java.util.List;

public class SubmissionService {
    private final SubmissionDAO submissionDAO;
    private final CodeExecutionService codeExecutionService;
    private final QuestionService questionService;
    private final UserService userService;

    public SubmissionService(QuestionService questionService, UserService userService) {
        this.submissionDAO = new SubmissionDAO();
        this.codeExecutionService = new CodeExecutionService();
        this.questionService = questionService;
        this.userService = userService;
    }

    public Submission submitSolution(User user, Question question, String code) throws SQLException {
        // Get test cases for the question
        List<TestCase> testCases = questionService.getTestCasesForQuestion(question.getId());
        boolean allTestsPassed = true;
        StringBuilder results = new StringBuilder();

        // Run all test cases
        for (TestCase testCase : testCases) {
            TestResult result = codeExecutionService.executeCode(code, testCase);
            if (!result.passed) {
                allTestsPassed = false;
                results.append("Test case failed: ").append(result.error).append("\n");
            }
        }

        // Create submission with status
        String status = allTestsPassed ? "ACCEPTED" : "FAILED";
        Submission submission = submissionDAO.createSubmission(
            user.getId(),
            question.getId(),
            code,
            status
        );

        // If all tests passed, increment user's solved count
        if (allTestsPassed) {
            userService.updateSolvedCount(user.getId());
        }

        return submission;
    }

    public List<Submission> getUserSubmissions(User user) throws SQLException {
        return submissionDAO.getUserSubmissions(user.getId());
    }

    public List<Submission> getQuestionSubmissions(Question question) throws SQLException {
        return submissionDAO.getQuestionSubmissions(question.getId());
    }
}