// src/main/java/com/codequest/ui/ChallengeHistoryPanel.java
package com.codequest.ui;

import com.codequest.model.*;
import com.codequest.dao.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.sql.SQLException;
import java.util.List;

public class ChallengeHistoryPanel extends JPanel {
    private final DefaultTableModel tableModel;
    private final JTable historyTable;
    private User currentUser;
    private final ChallengeRoomDAO roomDAO;
    private final JLabel totalScoreLabel;
    
    public ChallengeHistoryPanel(User user) {
        this.currentUser = user;
        this.roomDAO = new ChallengeRoomDAO();
        setLayout(new BorderLayout(5, 5));
        
        // Create table
        String[] columns = {"Date", "Challenge", "Position", "Score", "Participants"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        historyTable = new JTable(tableModel);
        historyTable.getColumnModel().getColumn(0).setPreferredWidth(150);
        historyTable.getColumnModel().getColumn(1).setPreferredWidth(200);
        
        // Add to scroll pane
        JScrollPane scrollPane = new JScrollPane(historyTable);
        
        // Create header panel
        JPanel headerPanel = new JPanel(new BorderLayout(5, 5));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JLabel titleLabel = new JLabel("Challenge History", SwingConstants.CENTER);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 14));
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> loadHistory());
        
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.add(refreshButton, BorderLayout.EAST);
        
        // Create total score panel
        totalScoreLabel = new JLabel("Total Score: 0", SwingConstants.CENTER);
        totalScoreLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        totalScoreLabel.setFont(totalScoreLabel.getFont().deriveFont(Font.BOLD));
        
        add(headerPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(totalScoreLabel, BorderLayout.SOUTH);
        
        if (currentUser != null) {
            loadHistory();
        }
    }
    
    public void updateUser(User user) {
        this.currentUser = user;
        loadHistory();
    }
    
    private void loadHistory() {
        if (currentUser == null) return;
        
        try {
            tableModel.setRowCount(0);
            List<ChallengeRoom> completedRooms = roomDAO.getUserCompletedRooms(currentUser.getId());
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            
            int totalScore = 0;
            
            for (ChallengeRoom room : completedRooms) {
                List<RoomParticipant> participants = roomDAO.getRoomParticipants(room.getId());
                
                // Sort participants by score
                participants.sort((p1, p2) -> Integer.compare(p2.getScore(), p1.getScore()));
                
                // Find user's position and score
                int position = 1;
                int userScore = 0;
                for (RoomParticipant p : participants) {
                    if (p.getUserId() == currentUser.getId()) {
                        userScore = p.getScore();
                        totalScore += userScore;
                        break;
                    }
                    position++;
                }
                
                tableModel.addRow(new Object[]{
                    room.getStartTime().format(formatter),
                    room.getName(),
                    getOrdinal(position),
                    userScore,
                    participants.size()
                });
            }
            
            totalScoreLabel.setText("Total Score: " + totalScore);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading challenge history: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String getOrdinal(int position) {
        String[] suffixes = new String[]{"th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th"};
        switch (position % 100) {
            case 11:
            case 12:
            case 13:
                return position + "th";
            default:
                return position + suffixes[position % 10];
        }
    }
}