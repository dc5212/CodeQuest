package com.codequest.ui;

import com.codequest.model.*;
import com.codequest.service.*;
import com.codequest.dao.ChallengeRoomDAO;


import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


public class ChallengeRoomPanel extends JPanel {
    // Member variables
    private final ChallengeRoom room;
    private final User currentUser;
    private final CodeEditorPanel codeEditor;
    private final JTable participantsTable;
    private final DefaultTableModel tableModel;
    private final CodeExecutionService executionService;
    private final QuestionService questionService;
    private final Timer roomStatusChecker;
    private final ChallengeRoomDAO roomDAO;

    // UI Components
    private final JButton runButton;
    private final JButton submitButton;
    private final JLabel timerLabel;
    private Timer challengeTimer;
    private int remainingTime;
    private final JButton startButton;
    private final JButton endChallengeButton; 
    private final Timer updateTimer;

    public ChallengeRoomPanel(ChallengeRoom room, User currentUser, QuestionService questionService) {
        this.room = room;
        this.currentUser = currentUser;
        this.questionService = questionService;
        this.executionService = new CodeExecutionService();
        this.roomDAO = new ChallengeRoomDAO();
        
        // Add room status checker
        roomStatusChecker = new Timer(1000, e -> checkRoomStatus());
        roomStatusChecker.start();

        // Initialize UI components first
        this.runButton = new JButton("Run Code");
        this.submitButton = new JButton("Submit Solution");
        this.timerLabel = new JLabel("Time Remaining: --:--");
        this.startButton = new JButton("Start Challenge");
        this.endChallengeButton = new JButton("End Challenge");
        this.codeEditor = new CodeEditorPanel();

        // Table setup
        String[] columns = {"Participant", "Status", "Score"};
        this.tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        this.participantsTable = new JTable(tableModel);

        
        setupUI();

        // Setup update timer for participants list
        this.updateTimer = new Timer(1000, e -> updateParticipantsList());
        this.updateTimer.start();

        // Initially disable controls
        setControlsEnabled(false);
    }

    private void setupUI() {
        setLayout(new BorderLayout());

        // Create left panel
        JPanel leftPanel = new JPanel(new BorderLayout());

        // Question panel
        Question question = null;
        try {
            question = questionService.getQuestionById(room.getQuestionId());
        } catch (SQLException e) {
            e.printStackTrace();
        }

        JTextPane questionPane = new JTextPane();
        questionPane.setContentType("text/html");
        if (question != null) {
            questionPane.setText(formatQuestionHTML(question));
        }
        questionPane.setEditable(false);

        // Control panel at the top
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        controlPanel.add(timerLabel);
        if (room.getCreatorId() == currentUser.getId()) {
            controlPanel.add(startButton);
            controlPanel.add(endChallengeButton);
            startButton.addActionListener(e -> startChallenge());
            endChallengeButton.addActionListener(e -> endChallenge());
            endChallengeButton.setEnabled(false);
        }

        leftPanel.add(controlPanel, BorderLayout.NORTH);
        leftPanel.add(new JScrollPane(questionPane), BorderLayout.CENTER);
        leftPanel.add(new JScrollPane(participantsTable), BorderLayout.SOUTH);

        // Create right panel
        JPanel rightPanel = new JPanel(new BorderLayout());
        if (question != null) {
            codeEditor.setTemplate(question.getJavaTemplate());
        }

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        runButton.addActionListener(e -> runCode());
        submitButton.addActionListener(e -> submitSolution());
        buttonPanel.add(runButton);
        buttonPanel.add(submitButton);

        rightPanel.add(codeEditor, BorderLayout.CENTER);
        rightPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Create split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(400);
        add(splitPane, BorderLayout.CENTER);
    }

 

	 private void checkRoomStatus() {
	     try {
	         ChallengeRoom updatedRoom = roomDAO.getRoom(room.getId());
	         if (updatedRoom != null) {
	             if ("COMPLETED".equals(updatedRoom.getStatus()) && !"COMPLETED".equals(room.getStatus())) {
	                 // Room just ended
	                 room.setStatus("COMPLETED");
	                 handleChallengeEnd();
	             } else if ("IN_PROGRESS".equals(updatedRoom.getStatus()) && "WAITING".equals(room.getStatus())) {
	                 // Room just started
	                 setControlsEnabled(true);
	                 startTimer();
	             }
	             room.setStatus(updatedRoom.getStatus());
	             room.setStartTime(updatedRoom.getStartTime());
	             room.setEndTime(updatedRoom.getEndTime());
	         }
	     } catch (SQLException e) {
	         e.printStackTrace();
	     }
	 }
	
	 private void handleChallengeEnd() {
	     if (challengeTimer != null) {
	         challengeTimer.stop();
	     }
	     setControlsEnabled(false);
	     showFinalScores();
	     
	     // Close room window after a short delay
	     Timer closeTimer = new Timer(3000, e -> {
	         Window window = SwingUtilities.getWindowAncestor(this);
	         if (window != null) {
	             window.dispose();
	         }
	     });
	     closeTimer.setRepeats(false);
	     closeTimer.start();
	 }

    private void setControlsEnabled(boolean enabled) {
        runButton.setEnabled(enabled);
        submitButton.setEnabled(enabled);
        codeEditor.setEnabled(enabled);
    }


    private String formatQuestionHTML(Question question) {
        return "<html><body style='font-family: Arial, sans-serif; margin: 10px;'>" +
                "<h2>" + question.getTitle() + "</h2>" +
                "<p><strong>Difficulty:</strong> <span style='color: " + getDifficultyColor(question.getDifficulty()) + "'>" +
                question.getDifficulty() + "</span></p>" +
                "<hr>" +
                question.getContent() +
                "</body></html>";
    }

    private String getDifficultyColor(String difficulty) {
        if ("Easy".equals(difficulty)) {
            return "#00aa00";
        } else if ("Medium".equals(difficulty)) {
            return "#ff8c00";
        } else if ("Hard".equals(difficulty)) {
            return "#ff0000";
        } else {
            return "#808080"; 
        }
    }

    private void startChallenge() {
        try {
            room.setStatus("IN_PROGRESS");
            room.setStartTime(LocalDateTime.now());
            roomDAO.updateRoomStatus(room);
            
            setControlsEnabled(true);
            startButton.setEnabled(false);
            endChallengeButton.setEnabled(true);
            
            startTimer();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error starting challenge: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void endChallenge() {
        try {
            ChallengeRoomDAO roomDAO = new ChallengeRoomDAO();
            
            // Stop timers
            if (challengeTimer != null) {
                challengeTimer.stop();
            }
            if (updateTimer != null) {
                updateTimer.stop();
            }
            
            // Update room status
            roomDAO.endChallenge(room.getId());
            
            // Disable controls
            setControlsEnabled(false);
            endChallengeButton.setEnabled(false);
            
            // Show final scores
            showFinalScores();
            
            JOptionPane.showMessageDialog(this,
                    "Challenge has ended. Final scores have been recorded.",
                    "Challenge Ended",
                    JOptionPane.INFORMATION_MESSAGE);
                
            // Close the room window
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window != null) {
                window.dispose();
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error ending challenge: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleRoomExit() {
        try {
            ChallengeRoomDAO roomDAO = new ChallengeRoomDAO();
            
            // Check if room is still active
            if (roomDAO.isRoomActive(room.getId())) {
                // Only remove participant if room is active and user is not the creator
                if (room.getCreatorId() != currentUser.getId()) {
                    roomDAO.removeParticipant(room.getId(), currentUser.getId());
                }
            }
            
            // Stop timers
            if (updateTimer != null) {
                updateTimer.stop();
            }
            if (challengeTimer != null) {
                challengeTimer.stop();
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showFinalScores() {
        try {
            List<RoomParticipant> participants = new ChallengeRoomDAO().getRoomParticipants(room.getId());
            StringBuilder scores = new StringBuilder("Final Scores:\n\n");
            
            participants.sort((p1, p2) -> Integer.compare(p2.getScore(), p1.getScore()));
            
            for (RoomParticipant participant : participants) {
                scores.append(String.format("%s: %d points\n", 
                    participant.getUsername(), 
                    participant.getScore()));
            }
            
            JOptionPane.showMessageDialog(this,
                    scores.toString(),
                    "Challenge Results",
                    JOptionPane.INFORMATION_MESSAGE);
                
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void startTimer() {
        if (challengeTimer != null) {
            challengeTimer.stop();
        }
        
        remainingTime = room.getDuration();
        updateTimerLabel();
        
        challengeTimer = new Timer(1000, e -> {
            if (remainingTime > 0) {
                remainingTime--;
                updateTimerLabel();
            } else {
                ((Timer) e.getSource()).stop();
                endChallenge();
            }
        });
        
        challengeTimer.start();
    }


    private void updateTimerLabel() {
        int minutes = remainingTime / 60;
        int seconds = remainingTime % 60;
        timerLabel.setText(String.format("Time Remaining: %02d:%02d", minutes, seconds));
    }

    private void updateParticipantsList() {
        try {
            List<RoomParticipant> participants = roomDAO.getRoomParticipants(room.getId());
            tableModel.setRowCount(0);
            
            // Sort participants: creator first, then by score
            participants.sort((p1, p2) -> {
                if (p1.getUserId() == room.getCreatorId()) return -1;
                if (p2.getUserId() == room.getCreatorId()) return 1;
                return Integer.compare(p2.getScore(), p1.getScore()); // Higher score first
            });
            
            for (RoomParticipant participant : participants) {
                String displayName = participant.getUsername();
                if (participant.getUserId() == room.getCreatorId()) {
                    displayName += " (Creator)";
                }
                if (participant.getUserId() == currentUser.getId()) {
                    displayName += " (You)";
                }
                
                tableModel.addRow(new Object[]{
                    displayName,
                    participant.getStatus(),
                    participant.getScore()
                });
            }
            
            
            Window window = SwingUtilities.getWindowAncestor(this);
            if (window instanceof JFrame) {
                JFrame frame = (JFrame) window;
                frame.setTitle(String.format("Challenge Room - %s (%d/%d participants)", 
                    room.getName(), participants.size(), room.getMaxParticipants()));
            } else if (window instanceof JDialog) {
                JDialog dialog = (JDialog) window;
                dialog.setTitle(String.format("Challenge Room - %s (%d/%d participants)", 
                    room.getName(), participants.size(), room.getMaxParticipants()));
            }

            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



	 private void runCode() {
	     String code = codeEditor.getCode();
	     try {
	         List<TestCase> testCases = questionService.getTestCasesForQuestion(room.getQuestionId());
	         if (!testCases.isEmpty()) {
	             TestCase firstCase = testCases.get(0);
	             
	             
	             TestResult result = executionService.executeCode(code, firstCase);
	             
	             
	             StringBuilder output = new StringBuilder();
	             if (result.isPassed()) {
	                 output.append("✓ Test case passed!\n\n");
	                 output.append("Input: ").append(firstCase.getInput()).append("\n");
	                 output.append("Expected: ").append(firstCase.getExpectedOutput()).append("\n");
	                 output.append("Your output: ").append(result.getOutput());
	             } else {
	                 output.append("✗ Test case failed\n\n");
	                 if (result.getError() != null && !result.getError().isEmpty()) {
	                     output.append("Error: ").append(result.getError()).append("\n");
	                 } else {
	                     output.append("Input: ").append(firstCase.getInput()).append("\n");
	                     output.append("Expected: ").append(firstCase.getExpectedOutput()).append("\n");
	                     output.append("Your output: ").append(result.getOutput());
	                 }
	             }
	             
	             codeEditor.setOutput(output.toString());
	         }
	     } catch (Exception e) {
	         codeEditor.setOutput("Error running code: " + e.getMessage());
	     }
	 }
	
	 private void submitSolution() {
	     String code = codeEditor.getCode();
	     try {
	         List<TestCase> testCases = questionService.getTestCasesForQuestion(room.getQuestionId());
	         boolean allPassed = true;
	         StringBuilder output = new StringBuilder();
	         int passedCount = 0;
	         
	         output.append("Running test cases...\n\n");
	         
	         for (int i = 0; i < testCases.size(); i++) {
	             TestCase testCase = testCases.get(i);
	             TestResult result = executionService.executeCode(code, testCase);
	             
	             output.append("Test Case ").append(i + 1).append(": ");
	             if (result.isPassed()) {
	                 output.append("✓ Passed\n");
	                 passedCount++;
	             } else {
	                 output.append("✗ Failed\n");
	                 output.append("Input: ").append(testCase.getInput()).append("\n");
	                 output.append("Expected: ").append(testCase.getExpectedOutput()).append("\n");
	                 output.append("Your output: ").append(result.getOutput()).append("\n");
	                 if (result.getError() != null && !result.getError().isEmpty()) {
	                     output.append("Error: ").append(result.getError()).append("\n");
	                 }
	                 allPassed = false;
	             }
	             output.append("\n");
	         }
	         
	         output.append(String.format("Test Cases Passed: %d/%d\n", passedCount, testCases.size()));
	         
	         // Update submission status
	         String status = allPassed ? "ACCEPTED" : "FAILED";
	         new ChallengeRoomDAO().submitSolution(room.getId(), currentUser.getId(), code, status);
	         
	         // Calculate and update score if passed
	         if (allPassed) {
	             int score = calculateScore(passedCount, testCases.size(), remainingTime);
	             new ChallengeRoomDAO().updateParticipantScore(room.getId(), currentUser.getId(), score);
	             output.append("\nScore: ").append(score).append(" points");
	         }
	         
	         codeEditor.setOutput(output.toString());
	         
	         // Show completion dialog
	         String message = allPassed ? 
	             "Congratulations! All test cases passed!" :
	             "Some test cases failed. Keep trying!";
	         
	         JOptionPane.showMessageDialog(this,
	             message,
	             "Submission Result",
	             allPassed ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE);
	             
	     } catch (Exception e) {
	         codeEditor.setOutput("Error submitting solution: " + e.getMessage());
	         JOptionPane.showMessageDialog(this,
	             "Error submitting solution: " + e.getMessage(),
	             "Error",
	             JOptionPane.ERROR_MESSAGE);
	     }
	 }
	
	 private int calculateScore(int passedTests, int totalTests, int remainingSeconds) {
	     // Base score for completing all tests
	     int baseScore = 100;
	     
	     // Calculate percentage of tests passed
	     double testPercentage = (double) passedTests / totalTests;
	     
	     // Time bonus (up to 50 points based on remaining time)
	     int timeBonus = (int) ((remainingSeconds / (30.0 * 60)) * 50);
	     
	     return (int) (baseScore * testPercentage) + timeBonus;
	 }
	 
	 @Override
	 public void removeNotify() {
	     super.removeNotify();
	     if (roomStatusChecker != null) {
	         roomStatusChecker.stop();
	     }
	     if (challengeTimer != null) {
	         challengeTimer.stop();
	     }
	     if (updateTimer != null) {
	         updateTimer.stop();
	     }
	 }
}
