
package com.codequest.ui;

import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;

public class CodeEditorPanel extends JPanel {
    private final RSyntaxTextArea codeArea;
    private final JTextPane outputArea;
    
    public CodeEditorPanel() {
        setLayout(new BorderLayout());
        
        // Create code editor
        codeArea = new RSyntaxTextArea(20, 60);
        codeArea.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_JAVA);
        codeArea.setCodeFoldingEnabled(true);
        codeArea.setAntiAliasingEnabled(true);
        
        // Create output area
        outputArea = new JTextPane();
        outputArea.setEditable(false);
        outputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        
        // Create split pane
        JSplitPane splitPane = new JSplitPane(
            JSplitPane.VERTICAL_SPLIT,
            new RTextScrollPane(codeArea),
            new JScrollPane(outputArea)
        );
        splitPane.setResizeWeight(0.7);
        
        add(splitPane, BorderLayout.CENTER);
    }
    
    public void setTemplate(String template) {
        codeArea.setText(template);
        codeArea.setCaretPosition(0);
        clearOutput();
    }
    
    public String getCode() {
        return codeArea.getText();
    }
    
    public void setOutput(String output) {
        outputArea.setText("");
        StyledDocument doc = outputArea.getStyledDocument();
        
        SimpleAttributeSet defaultStyle = new SimpleAttributeSet();
        StyleConstants.setFontFamily(defaultStyle, Font.MONOSPACED);
        StyleConstants.setFontSize(defaultStyle, 12);

        SimpleAttributeSet passedStyle = new SimpleAttributeSet(defaultStyle);
        StyleConstants.setForeground(passedStyle, new Color(0, 150, 0));
        StyleConstants.setBold(passedStyle, true);

        SimpleAttributeSet failedStyle = new SimpleAttributeSet(defaultStyle);
        StyleConstants.setForeground(failedStyle, new Color(200, 0, 0));
        StyleConstants.setBold(failedStyle, true);

        try {
            String[] lines = output.split("\n");
            for (String line : lines) {
                if (line.contains("PASSED")) {
                    doc.insertString(doc.getLength(), line + "\n", passedStyle);
                } else if (line.contains("FAILED")) {
                    doc.insertString(doc.getLength(), line + "\n", failedStyle);
                } else {
                    doc.insertString(doc.getLength(), line + "\n", defaultStyle);
                }
            }
        } catch (BadLocationException e) {
            e.printStackTrace();
            outputArea.setText(output); // Fallback to plain text
        }
    }
    
    public void clearOutput() {
        outputArea.setText("");
    }
}