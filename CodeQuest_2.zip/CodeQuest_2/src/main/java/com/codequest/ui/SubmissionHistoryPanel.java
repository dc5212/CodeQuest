
package com.codequest.ui;

import com.codequest.model.Submission;
import com.codequest.service.SubmissionService;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class SubmissionHistoryPanel extends JPanel {
    private final SubmissionService submissionService;
    private final DefaultTableModel tableModel;
    private final JTable table;
    
    public SubmissionHistoryPanel(SubmissionService submissionService) {
        this.submissionService = submissionService;
        setLayout(new BorderLayout());
        
        // Create table model with column names
        String[] columns = {"Time", "Question", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Create and configure table
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        table.getColumnModel().getColumn(2).setCellRenderer(new StatusRenderer());
        
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.add(new JLabel("Submission History", SwingConstants.CENTER), BorderLayout.CENTER);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        add(titlePanel, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
    }
    
    public void updateHistory(List<Submission> submissions) {
        SwingUtilities.invokeLater(() -> {
            tableModel.setRowCount(0);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            
            for (Submission submission : submissions) {
                tableModel.addRow(new Object[]{
                    submission.getSubmissionTime().format(formatter),
                    "Question " + submission.getQuestionId(),
                    submission.getStatus()
                });
            }
            
            if (submissions.isEmpty()) {
                tableModel.addRow(new Object[]{"No submissions yet", "", ""});
            }
        });
    }
    
    private static class StatusRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            
            Component c = super.getTableCellRendererComponent(
                table, value, isSelected, hasFocus, row, column);
            
            if ("ACCEPTED".equals(value)) {
                setForeground(new Color(0, 150, 0));
                setFont(getFont().deriveFont(Font.BOLD));
            } else if ("FAILED".equals(value)) {
                setForeground(new Color(200, 0, 0));
            }
            
            return this;
        }
    }
}