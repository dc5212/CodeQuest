package com.codequest.ui;

import com.codequest.model.Question;
import javax.swing.*;
import java.awt.*;

public class QuestionDetailPanel extends JPanel {
    private final JTextPane contentPane;
    
    public QuestionDetailPanel() {
        setLayout(new BorderLayout());
        
        contentPane = new JTextPane();
        contentPane.setContentType("text/html");
        contentPane.setEditable(false);
        contentPane.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, Boolean.TRUE);
        contentPane.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        
        add(new JScrollPane(contentPane), BorderLayout.CENTER);
    }
    
    public void setQuestion(Question question) {
        if (question == null) {
            contentPane.setText("");
            return;
        }
        
        
        StringBuilder html = new StringBuilder();
        html.append("<html><body style='font-family: Arial, sans-serif; margin: 10px;'>");
        html.append("<h2>").append(question.getTitle()).append("</h2>");
        html.append("<p><strong>Difficulty: </strong>");
        html.append("<span style='color: ").append(getDifficultyColor(question.getDifficulty())).append("'>");
        html.append(question.getDifficulty()).append("</span></p>");
        html.append("<hr>");
        html.append(question.getContent());
        html.append("</body></html>");
        
        contentPane.setText(html.toString());
        contentPane.setCaretPosition(0);
    }
    
    private String getDifficultyColor(String difficulty) {
        if ("Easy".equals(difficulty)) {
            return "#00aa00";
        } else if ("Medium".equals(difficulty)) {
            return "#ff8c00";
        } else if ("Hard".equals(difficulty)) {
            return "#ff0000";
        }
        return "#808080";
    }
}