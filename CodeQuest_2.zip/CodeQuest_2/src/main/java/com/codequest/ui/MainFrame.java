package com.codequest.ui;

import com.codequest.model.*;
import com.codequest.service.*;
import com.codequest.dao.ChallengeRoomDAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MainFrame extends JFrame {
    private final QuestionService questionService;
    private final UserService userService;
    private final SubmissionService submissionService;
    private final CodeExecutionService codeExecutionService;
    
    private User currentUser;
    private Question currentQuestion;
    
    private QuestionListPanel questionListPanel;
    private QuestionDetailPanel questionDetailPanel;
    private CodeEditorPanel codeEditorPanel;
    private SubmissionHistoryPanel submissionHistoryPanel;
    private JLabel userLabel;
    private JLabel statusLabel;
    private JMenuBar menuBar;
    private ChallengeHistoryPanel historyPanel;
    private JTabbedPane leftPane;
    
    
    public MainFrame(QuestionService questionService, UserService userService) {
        this.questionService = questionService;
        this.userService = userService;
        this.submissionService = new SubmissionService(questionService, userService);
        this.codeExecutionService = new CodeExecutionService();
        
        initializeMenuBar();
        initializeComponents();
        setupUI();
        showLoginDialog();
    }
    
    private void initializeMenuBar() {
        menuBar = new JMenuBar();

        // Exit Button
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(e -> System.exit(0));

        // Challenge Room Menu
        JMenu challengeMenu = new JMenu("Challenge Rooms");
        JMenuItem createRoom = new JMenuItem("Create Room");
        JMenuItem joinRoom = new JMenuItem("Join Room");

        createRoom.addActionListener(e -> showCreateRoomDialog());
        joinRoom.addActionListener(e -> showJoinRoomDialog());

        challengeMenu.add(createRoom);
        challengeMenu.add(joinRoom);

        // Add components to the menu bar
        menuBar.add(exitButton); // Add the exit button directly to the menu bar
        menuBar.add(challengeMenu);

        setJMenuBar(menuBar);
    }

    
    private void initializeComponents() {
        questionListPanel = new QuestionListPanel(questionService);
        questionDetailPanel = new QuestionDetailPanel();
        codeEditorPanel = new CodeEditorPanel();
        submissionHistoryPanel = new SubmissionHistoryPanel(submissionService);
        userLabel = new JLabel();
        statusLabel = new JLabel(" Ready");
        
        questionListPanel.addQuestionSelectionListener(this::onQuestionSelected);
    }
    
 // Update the setupUI method in MainFrame.java

    private void setupUI() {
        setTitle("CodeQuest - Collaborative Programming Practice");
        setLayout(new BorderLayout());
        
        JSplitPane mainSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        
        // Left panel with questions and history
        leftPane = new JTabbedPane();
        
        leftPane.addTab("Practice Questions", new JScrollPane(questionListPanel));
        leftPane.addTab("Submission History", submissionHistoryPanel);
        
        // Right panel with question detail and code editor
        JSplitPane rightSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        rightSplitPane.setTopComponent(questionDetailPanel);
        rightSplitPane.setBottomComponent(codeEditorPanel);
        rightSplitPane.setResizeWeight(0.3);
        
        mainSplitPane.setLeftComponent(leftPane);
        mainSplitPane.setRightComponent(rightSplitPane);
        mainSplitPane.setResizeWeight(0.3);
        
        add(createToolBar(), BorderLayout.NORTH);
        add(mainSplitPane, BorderLayout.CENTER);
        
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        statusBar.add(statusLabel, BorderLayout.WEST);
        add(statusBar, BorderLayout.SOUTH);
        
        setSize(1200, 800);
        setLocationRelativeTo(null);
    }
    
 
    private JToolBar createToolBar() {
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        
        JButton runButton = new JButton("Run Code");
        JButton submitButton = new JButton("Submit Solution");
        
        runButton.setToolTipText("Run code with sample test case (Ctrl+R)");
        submitButton.setToolTipText("Submit solution for all test cases (Ctrl+Enter)");
        
        runButton.addActionListener(e -> runCode());
        submitButton.addActionListener(e -> submitSolution());
        
        toolBar.add(runButton);
        toolBar.add(submitButton);
        toolBar.addSeparator();
        
        toolBar.add(new JLabel(" Difficulty: "));
        JComboBox<String> difficultyFilter = new JComboBox<>(
            new String[]{"All", "Easy", "Medium", "Hard"}
        );
        difficultyFilter.addActionListener(e -> {
            String selectedDifficulty = (String) difficultyFilter.getSelectedItem();
            questionListPanel.loadQuestions(selectedDifficulty);  // Use loadQuestions directly
        });
        toolBar.add(difficultyFilter);
        
        toolBar.add(Box.createHorizontalGlue());
        userLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        toolBar.add(userLabel);
        
        return toolBar;
    }
    
    private void showLoginDialog() {
        LoginDialog loginDialog = new LoginDialog(this, userService);
        loginDialog.setVisible(true);
        
        if (loginDialog.isLoginSuccessful()) {
            currentUser = loginDialog.getUser();
            updateUserDisplay();
        } else {
            System.exit(0);
        }
    }
    

	private void updateUserDisplay() {
	    setTitle("CodeQuest - " + currentUser.getUsername());
	    
	    
	    for (int i = 0; i < leftPane.getTabCount(); i++) {
	        if (leftPane.getTitleAt(i).equals("Challenge History")) {
	            leftPane.removeTabAt(i);
	            i--; // Adjust index after removal
	        }
	    }
	    
	    // Add single new history panel
	    historyPanel = new ChallengeHistoryPanel(currentUser);
	    leftPane.addTab("Challenge History", historyPanel);
	}
    
    private void onQuestionSelected(Question question) {
        this.currentQuestion = question;
        questionDetailPanel.setQuestion(question);
        codeEditorPanel.setTemplate(question.getJavaTemplate());
    }
    
    private void showCreateRoomDialog() {
        JDialog dialog = new JDialog(this, "Create Challenge Room", true);
        dialog.setLayout(new BorderLayout(10, 10));
        
        JPanel inputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Room name input
        gbc.gridx = 0; gbc.gridy = 0;
        inputPanel.add(new JLabel("Room Name:"), gbc);
        JTextField nameField = new JTextField(20);
        gbc.gridx = 1;
        inputPanel.add(nameField, gbc);
        
        // Question selection
        gbc.gridx = 0; gbc.gridy = 1;
        inputPanel.add(new JLabel("Question:"), gbc);
        JComboBox<Question> questionBox = new JComboBox<>();
        try {
            for (Question q : questionService.getAllQuestions()) {
                questionBox.addItem(q);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        gbc.gridx = 1;
        inputPanel.add(questionBox, gbc);
        
        // Max participants
        gbc.gridx = 0; gbc.gridy = 2;
        inputPanel.add(new JLabel("Max Participants:"), gbc);
        SpinnerNumberModel spinnerModel = new SpinnerNumberModel(5, 2, 10, 1);
        JSpinner maxParticipants = new JSpinner(spinnerModel);
        gbc.gridx = 1;
        inputPanel.add(maxParticipants, gbc);
        
        // Buttons
        JPanel buttonPanel = new JPanel();
        JButton createButton = new JButton("Create");
        JButton cancelButton = new JButton("Cancel");
        
        createButton.addActionListener(e -> {
            try {
                String roomName = nameField.getText().trim();
                Question selectedQuestion = (Question) questionBox.getSelectedItem();
                int maxPart = (Integer) maxParticipants.getValue();
                
                if (roomName.isEmpty() || selectedQuestion == null) {
                    JOptionPane.showMessageDialog(dialog,
                        "Please fill all fields",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                ChallengeRoom room = new ChallengeRoomDAO().createRoom(
                    roomName,
                    currentUser.getId(),
                    selectedQuestion.getId(),
                    LocalDateTime.now(),
                    maxPart
                );
                
                dialog.dispose();
                openChallengeRoom(room);
                
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog,
                    "Error creating room: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        cancelButton.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(createButton);
        buttonPanel.add(cancelButton);
        
        dialog.add(inputPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    
    private void showJoinRoomDialog() {
        JDialog dialog = new JDialog(this, "Join Challenge Room", true);
        dialog.setLayout(new BorderLayout(10, 10));
        
        // Create table model for rooms
        String[] columns = {"Room ID", "Room Name", "Creator", "Question", "Status", "Participants"};
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable roomsTable = new JTable(tableModel);
        roomsTable.getColumnModel().getColumn(0).setMinWidth(0);
        roomsTable.getColumnModel().getColumn(0).setMaxWidth(0);
        roomsTable.getColumnModel().getColumn(0).setWidth(0);
        
        // Function to load rooms
        AtomicReference<List<ChallengeRoom>> roomsList = new AtomicReference<>(new ArrayList<>());
        
        Runnable loadRooms = () -> {
            tableModel.setRowCount(0);
            try {
                List<ChallengeRoom> rooms = new ChallengeRoomDAO().getActiveRooms();
                roomsList.set(rooms);
                
                for (ChallengeRoom room : rooms) {
                    Question question = questionService.getQuestionById(room.getQuestionId());
                    User creator = userService.getUserById(room.getCreatorId());
                    List<RoomParticipant> participants = new ChallengeRoomDAO().getRoomParticipants(room.getId());
                    
                    tableModel.addRow(new Object[]{
                        room.getId(),
                        room.getName(),
                        creator.getUsername(),
                        question.getTitle(),
                        room.getStatus(),
                        participants.size() + "/" + room.getMaxParticipants()
                    });
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(dialog,
                    "Error loading rooms: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        };
        
        JButton joinButton = new JButton("Join Selected Room");
        JButton refreshButton = new JButton("Refresh");
        JButton cancelButton = new JButton("Cancel");
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(joinButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(cancelButton);
        
        joinButton.addActionListener(e -> {
            int selectedRow = roomsTable.getSelectedRow();
            if (selectedRow >= 0) {
                try {
                    int roomId = (int) roomsTable.getValueAt(selectedRow, 0);
                    ChallengeRoom selectedRoom = roomsList.get().stream()
                        .filter(r -> r.getId() == roomId)
                        .findFirst()
                        .orElseThrow(() -> new Exception("Room not found"));
                    
                    ChallengeRoomDAO roomDAO = new ChallengeRoomDAO();
                    
                    // Check if room is still active
                    if (!roomDAO.isRoomActive(roomId)) {
                        throw new Exception("This challenge has ended");
                    }
                    
                    // Check if room is full
                    List<RoomParticipant> participants = roomDAO.getRoomParticipants(roomId);
                    if (participants.size() >= selectedRoom.getMaxParticipants()) {
                        throw new Exception("Room is full");
                    }
                    
                    // Check if user is already in the room
                    boolean alreadyJoined = participants.stream()
                        .anyMatch(p -> p.getUserId() == currentUser.getId());
                        
                    if (!alreadyJoined) {
                        roomDAO.addParticipant(roomId, currentUser.getId());
                    }
                    
                    dialog.dispose();
                    openChallengeRoom(selectedRoom);
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog,
                        "Error joining room: " + ex.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        refreshButton.addActionListener(e -> loadRooms.run());
        cancelButton.addActionListener(e -> dialog.dispose());
        
        // Initial load
        loadRooms.run();
        
        dialog.add(new JScrollPane(roomsTable), BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.setSize(800, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }


	 private void openChallengeRoom(ChallengeRoom room) {
	     try {
	         JFrame roomFrame = new JFrame("Challenge Room - " + room.getName());
	         ChallengeRoomPanel roomPanel = new ChallengeRoomPanel(room, currentUser, questionService);
	         
	         roomFrame.setContentPane(roomPanel);
	         roomFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	         roomFrame.addWindowListener(new WindowAdapter() {
	             @Override
	             public void windowClosing(WindowEvent e) {
	                 try {
	                     new ChallengeRoomDAO().removeParticipant(room.getId(), currentUser.getId());
	                 } catch (SQLException ex) {
	                     ex.printStackTrace();
	                 }
	             }
	         });
	         
	         roomFrame.setSize(1024, 768);
	         roomFrame.setLocationRelativeTo(this);
	         roomFrame.setVisible(true);
	         
	     } catch (Exception e) {
	         JOptionPane.showMessageDialog(this,
	             "Error opening challenge room: " + e.getMessage(),
	             "Error",
	             JOptionPane.ERROR_MESSAGE);
	     }
	 }
    
    private void runCode() {
        if (currentQuestion == null) {
            JOptionPane.showMessageDialog(this,
                "Please select a question first",
                "No Question Selected",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        String code = codeEditorPanel.getCode();
        try {
            List<TestCase> testCases = questionService.getTestCasesForQuestion(currentQuestion.getId());
            if (!testCases.isEmpty()) {
                // Run first test case
                TestCase firstCase = testCases.get(0);
                TestResult result = codeExecutionService.executeCode(code, firstCase);
                
                StringBuilder output = new StringBuilder();
                output.append("Test case result:\n");
                output.append("Input: ").append(firstCase.getInput()).append("\n");
                output.append("Expected: ").append(firstCase.getExpectedOutput()).append("\n");
                output.append("Got: ").append(result.getOutput()).append("\n");
                output.append(result.isPassed() ? "PASSED" : "FAILED").append("\n\n");
                
                if (!result.isPassed()) {
                    output.append("Error details:\n").append(result.getError());
                }
                
                codeEditorPanel.setOutput(output.toString());
            } else {
                codeEditorPanel.setOutput("No test cases available for this question.");
            }
        } catch (Exception e) {
            codeEditorPanel.setOutput("Error running code: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void submitSolution() {
        if (currentQuestion == null || currentUser == null) {
            JOptionPane.showMessageDialog(this,
                "Please select a question and ensure you're logged in",
                "Cannot Submit",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            String code = codeEditorPanel.getCode();
            StringBuilder results = new StringBuilder();
            boolean allTestsPassed = true;
            List<TestCase> testCases = questionService.getTestCasesForQuestion(currentQuestion.getId());
            
            results.append("Running all test cases:\n\n");
            
            for (int i = 0; i < testCases.size(); i++) {
                TestCase testCase = testCases.get(i);
                TestResult result = codeExecutionService.executeCode(code, testCase);
                
                results.append("Test case ").append(i + 1).append(":\n");
                results.append("Input: ").append(testCase.getInput()).append("\n");
                results.append("Expected: ").append(testCase.getExpectedOutput()).append("\n");
                results.append("Got: ").append(result.getOutput()).append("\n");
                results.append(result.isPassed() ? "PASSED" : "FAILED").append("\n\n");
                
                if (!result.isPassed()) {
                    allTestsPassed = false;
                }
}
            
            
            codeEditorPanel.setOutput(results.toString());

            if (allTestsPassed) {
                Submission submission = submissionService.submitSolution(currentUser, currentQuestion, code);
                
                // Refresh user's solved count
                currentUser = userService.getUserById(currentUser.getId());
                updateUserDisplay();
                
                // Update submission history
                submissionHistoryPanel.updateHistory(submissionService.getUserSubmissions(currentUser));
                
                JOptionPane.showMessageDialog(this,
                    "Congratulations! All test cases passed!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Some test cases failed. Check the output panel for details.",
                    "Test Failed",
                    JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            String errorMessage = "Error submitting solution: " + e.getMessage();
            codeEditorPanel.setOutput(errorMessage);
            JOptionPane.showMessageDialog(this,
                errorMessage,
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}