package com.codequest.ui;

import com.codequest.model.User;
import com.codequest.service.UserService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.Optional;

public class LoginDialog extends JDialog {
    private final UserService userService;
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private User user;
    private boolean loginSuccessful;
    
    public LoginDialog(Frame owner, UserService userService) {
        super(owner, "Login", true);
        this.userService = userService;
        
        setLayout(new BorderLayout());
        
        // Create form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        formPanel.add(usernameField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);
        
        // Create buttons panel
        JPanel buttonsPanel = new JPanel();
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");
        
        loginButton.addActionListener(e -> login());
        registerButton.addActionListener(e -> register());
        
        buttonsPanel.add(loginButton);
        buttonsPanel.add(registerButton);
        
        add(formPanel, BorderLayout.CENTER);
        add(buttonsPanel, BorderLayout.SOUTH);
        
        pack();
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
    
    private void login() {
        try {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            
            Optional<User> userOptional = userService.authenticate(username, password);
            
            if (userOptional.isPresent()) {
                user = userOptional.get();
                loginSuccessful = true;
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                    "Invalid username or password",
                    "Login Failed",
                    JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Database error: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void register() {
        try {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            
            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                    "Username and password cannot be empty",
                    "Registration Failed",
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            user = userService.createUser(username, password);
            loginSuccessful = true;
            dispose();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Registration failed: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public User getUser() {
        return user;
    }
    
    public boolean isLoginSuccessful() {
        return loginSuccessful;
    }
}