// src/main/java/com/codequest/ui/QuestionListPanel.java
package com.codequest.ui;

import com.codequest.model.Question;
import com.codequest.service.QuestionService;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.util.function.Consumer;

public class QuestionListPanel extends JPanel {
    private final QuestionService questionService;
    private final DefaultListModel<Question> listModel;
    private final JList<Question> questionList;
    private Consumer<Question> selectionListener;
    
    public QuestionListPanel(QuestionService questionService) {
        this.questionService = questionService;
        this.listModel = new DefaultListModel<>();
        
        setLayout(new BorderLayout());
        
        // Create question list
        questionList = new JList<>(listModel);
        questionList.setCellRenderer(new QuestionListCellRenderer());
        questionList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && selectionListener != null) {
                Question selected = questionList.getSelectedValue();
                if (selected != null) {
                    selectionListener.accept(selected);
                }
            }
        });
        
        // Add list directly to panel without the filter combobox
        add(new JScrollPane(questionList), BorderLayout.CENTER);
        
        loadQuestions("All");  // Initial load
    }

    public void loadQuestions(String difficulty) {
        listModel.clear();
        try {
            List<Question> questions;
            if ("All".equals(difficulty)) {
                questions = questionService.getAllQuestions();
            } else {
                questions = questionService.getQuestionsByDifficulty(difficulty);
            }
            questions.forEach(listModel::addElement);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Error loading questions: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    public void addQuestionSelectionListener(Consumer<Question> listener) {
        this.selectionListener = listener;
    }

    private static class QuestionListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(
                JList<?> list, Object value, int index,
                boolean isSelected, boolean cellHasFocus) {
            
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            
            if (value instanceof Question) {
                Question question = (Question) value;
                setText(question.getTitle());
                setIcon(getDifficultyIcon(question.getDifficulty()));
            }
            
            return this;
        }
        
        private Icon getDifficultyIcon(String difficulty) {
            Color color;
            switch (difficulty) {
                case "Easy":
                    color = new Color(76, 175, 80); // Green
                    break;
                case "Medium":
                    color = new Color(255, 152, 0); // Orange
                    break;
                case "Hard":
                    color = new Color(244, 67, 54); // Red
                    break;
                default:
                    color = Color.GRAY;
                    break;
            }
            return new ColorIcon(color);
        }

    }

    private static class ColorIcon implements Icon {
        private final Color color;
        private static final int SIZE = 8;

        public ColorIcon(Color color) {
            this.color = color;
        }

        @Override
        public void paintIcon(Component c, Graphics g, int x, int y) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(color);
            g2d.fillOval(x, y + (getIconHeight() - SIZE) / 2, SIZE, SIZE);
            g2d.dispose();
        }

        @Override
        public int getIconWidth() {
            return SIZE + 4;
        }

        @Override
        public int getIconHeight() {
            return 16;
        }
    }
}