package com.codequest;

import com.codequest.config.DatabaseConfig;
import com.codequest.service.QuestionService;
import com.codequest.service.UserService;
import com.codequest.ui.MainFrame;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.Statement;

public class Main {
    public static void main(String[] args) {
        // Set the look and feel to the system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        initializeDatabase();

        // Initialize services
        QuestionService questionService = new QuestionService();
        UserService userService = new UserService();

        // Start the UI
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame(questionService, userService);
            mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            // Center the frame on screen
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            mainFrame.setSize(1024, 768);
            mainFrame.setLocation(
                (screenSize.width - mainFrame.getWidth()) / 2,
                (screenSize.height - mainFrame.getHeight()) / 2
            );
            
            mainFrame.setVisible(true);
        });
    }

    private static void initializeDatabase() {
        try (Connection conn = DatabaseConfig.getInstance().getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Create users table if it doesn't exist
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE, " +
                "password TEXT NOT NULL, " +
                "solved_count INTEGER DEFAULT 0" +
                ")"
            );

            // Create submissions table if it doesn't exist
            stmt.execute(
                "CREATE TABLE IF NOT EXISTS submissions (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "question_id INTEGER NOT NULL, " +
                "code TEXT NOT NULL, " +
                "status TEXT NOT NULL, " +
                "submission_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY (user_id) REFERENCES users (id), " +
                "FOREIGN KEY (question_id) REFERENCES questions (id)" +
                ")"
            );

        } catch (Exception e) {
            System.err.println("Error initializing database: " + e.getMessage());
            System.exit(1);
        }
    }
}