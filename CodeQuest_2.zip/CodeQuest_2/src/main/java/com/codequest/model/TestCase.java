
package com.codequest.model;

public class TestCase {
    private int id;
    private int questionId;
    private String input;
    private String expectedOutput;

    public TestCase(int id, int questionId, String input, String expectedOutput) {
        this.id = id;
        this.questionId = questionId;
        this.input = input;
        this.expectedOutput = expectedOutput;
    }

    // Getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getQuestionId() { return questionId; }
    public void setQuestionId(int questionId) { this.questionId = questionId; }
    public String getInput() { return input; }
    public void setInput(String input) { this.input = input; }
    public String getExpectedOutput() { return expectedOutput; }
    public void setExpectedOutput(String expectedOutput) { this.expectedOutput = expectedOutput; }
}