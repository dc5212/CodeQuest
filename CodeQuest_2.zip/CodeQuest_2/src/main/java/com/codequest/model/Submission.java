
package com.codequest.model;

import java.time.LocalDateTime;

public class Submission {
    private int id;
    private int userId;
    private int questionId;
    private String code;
    private String status;
    private LocalDateTime submissionTime;

    public Submission(int id, int userId, int questionId, String code, String status, LocalDateTime submissionTime) {
        this.id = id;
        this.userId = userId;
        this.questionId = questionId;
        this.code = code;
        this.status = status;
        this.submissionTime = submissionTime;
    }

    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getQuestionId() { return questionId; }
    public void setQuestionId(int questionId) { this.questionId = questionId; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getSubmissionTime() { return submissionTime; }
    public void setSubmissionTime(LocalDateTime submissionTime) { this.submissionTime = submissionTime; }
}