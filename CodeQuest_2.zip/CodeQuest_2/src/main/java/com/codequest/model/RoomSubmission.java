
package com.codequest.model;

import java.time.LocalDateTime;

public class RoomSubmission {
    private int id;
    private int roomId;
    private int userId;
    private String code;
    private String status;
    private LocalDateTime submissionTime;
    private long executionTime;  
    private long memoryUsed;     

    // Constructor
    public RoomSubmission(int id, int roomId, int userId, String code, 
                         String status, LocalDateTime submissionTime, 
                         long executionTime, long memoryUsed) {
        this.id = id;
        this.roomId = roomId;
        this.userId = userId;
        this.code = code;
        this.status = status;
        this.submissionTime = submissionTime;
        this.executionTime = executionTime;
        this.memoryUsed = memoryUsed;
    }

    
}