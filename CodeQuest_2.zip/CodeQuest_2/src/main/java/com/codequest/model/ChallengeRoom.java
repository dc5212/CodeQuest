package com.codequest.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ChallengeRoom {
    private int id;
    private String name;
    private int creatorId;
    private int questionId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String status;
    private int maxParticipants;
    private List<RoomParticipant> participants;
    private int duration; 

    public ChallengeRoom(int id, String name, int creatorId, int questionId, 
                        LocalDateTime startTime, LocalDateTime endTime, 
                        String status, int maxParticipants) {
        this.id = id;
        this.name = name;
        this.creatorId = creatorId;
        this.questionId = questionId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
        this.maxParticipants = maxParticipants;
        this.participants = new ArrayList<>();
        this.duration = 1800;
    }

    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getCreatorId() { return creatorId; }
    public void setCreatorId(int creatorId) { this.creatorId = creatorId; }
    public int getQuestionId() { return questionId; }
    public void setQuestionId(int questionId) { this.questionId = questionId; }
    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getMaxParticipants() { return maxParticipants; }
    public void setMaxParticipants(int maxParticipants) { this.maxParticipants = maxParticipants; }
    public List<RoomParticipant> getParticipants() { return participants; }
    public void setParticipants(List<RoomParticipant> participants) { this.participants = participants; }
    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
}

