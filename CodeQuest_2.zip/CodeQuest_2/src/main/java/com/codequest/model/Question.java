package com.codequest.model;

public class Question {
    private int id;
    private String title;
    private String content;
    private String difficulty;
    private String javaTemplate;

    public Question(int id, String title, String content, String difficulty, String javaTemplate) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.difficulty = difficulty;
        this.javaTemplate = javaTemplate;
    }

    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
    public String getJavaTemplate() { return javaTemplate; }
    public void setJavaTemplate(String javaTemplate) { this.javaTemplate = javaTemplate; }

    @Override
    public String toString() {
        return String.format("[%d] %s (%s)", id, title, difficulty);
    }
}

