
package com.codequest.model;

import java.time.LocalDateTime;

public class RoomParticipant {
    private int roomId;
    private int userId;
    private String username;
    private LocalDateTime joinTime;
    private LocalDateTime completedAt;
    private int score;
    private String status;  

    public RoomParticipant(int roomId, int userId, String username, 
                          LocalDateTime joinTime, LocalDateTime completedAt, 
                          int score) {
        this.roomId = roomId;
        this.userId = userId;
        this.username = username;
        this.joinTime = joinTime;
        this.completedAt = completedAt;
        this.score = score;
        this.status = completedAt != null ? "COMPLETED" : "IN_PROGRESS";
    }

    
    public int getRoomId() { return roomId; }
    public void setRoomId(int roomId) { this.roomId = roomId; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public LocalDateTime getJoinTime() { return joinTime; }
    public void setJoinTime(LocalDateTime joinTime) { this.joinTime = joinTime; }
    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { 
        this.completedAt = completedAt;
        this.status = completedAt != null ? "COMPLETED" : "IN_PROGRESS";
    }
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }

    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("%s (%s) - Score: %d", username, status, score);
    }
}