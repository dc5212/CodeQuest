
package com.codequest.model;

public class TestResult {
    public final boolean passed;
    public final String output;
    public final String error;

    public TestResult(boolean passed, String output, String error) {
        this.passed = passed;
        this.output = output;
        this.error = error;
    }

    public boolean isPassed() {
        return passed;
    }

    public String getOutput() {
        return output;
    }

    public String getError() {
        return error;
    }
}