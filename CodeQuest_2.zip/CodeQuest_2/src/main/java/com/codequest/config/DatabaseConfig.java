package com.codequest.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.nio.file.Paths;

public class DatabaseConfig {
    private static final String DB_URL = "jdbc:sqlite:" + Paths.get("src", "main", "resources", "database", "codequest.db").toString();
    private static DatabaseConfig instance;
    
    private DatabaseConfig() {
        // Initialize database connection
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("SQLite JDBC Driver not found", e);
        }
    }
    
    public static DatabaseConfig getInstance() {
        if (instance == null) {
            instance = new DatabaseConfig();
        }
        return instance;
    }
    
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }
}
