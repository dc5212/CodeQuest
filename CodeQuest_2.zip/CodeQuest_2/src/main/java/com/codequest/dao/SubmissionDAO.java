
package com.codequest.dao;

import com.codequest.config.DatabaseConfig;
import com.codequest.model.Submission;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SubmissionDAO {
    private final DatabaseConfig dbConfig;

    public SubmissionDAO() {
        this.dbConfig = DatabaseConfig.getInstance();
    }

    public Submission createSubmission(int userId, int questionId, String code, String status) throws SQLException {
        String sql = "INSERT INTO submissions (user_id, question_id, code, status, submission_time) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, userId);
            pstmt.setInt(2, questionId);
            pstmt.setString(3, code);
            pstmt.setString(4, status);
            pstmt.setTimestamp(5, Timestamp.valueOf(LocalDateTime.now()));
            
            pstmt.executeUpdate();

            
            if ("ACCEPTED".equals(status)) {
                updateUserSolvedCount(conn, userId, questionId);
            }
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return new Submission(
                    rs.getInt(1),
                    userId,
                    questionId,
                    code,
                    status,
                    LocalDateTime.now()
                );
            }
            throw new SQLException("Failed to create submission");
        }
    }

    private void updateUserSolvedCount(Connection conn, int userId, int questionId) throws SQLException {
        // Check if this is the first time solving this question
        String checkSql = "SELECT COUNT(*) FROM submissions WHERE user_id = ? AND question_id = ? AND status = 'ACCEPTED'";
        try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setInt(1, userId);
            checkStmt.setInt(2, questionId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                // First time solving, increment solved count
                String updateSql = "UPDATE users SET solved_count = solved_count + 1 WHERE id = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setInt(1, userId);
                    updateStmt.executeUpdate();
                }
            }
        }
    }

    public List<Submission> getUserSubmissions(int userId) throws SQLException {
        List<Submission> submissions = new ArrayList<>();
        String sql = "SELECT * FROM submissions WHERE user_id = ? ORDER BY submission_time DESC";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                submissions.add(new Submission(
                    rs.getInt("id"),
                    rs.getInt("user_id"),
                    rs.getInt("question_id"),
                    rs.getString("code"),
                    rs.getString("status"),
                    rs.getTimestamp("submission_time").toLocalDateTime()
                ));
            }
        }
        return submissions;
    }
}