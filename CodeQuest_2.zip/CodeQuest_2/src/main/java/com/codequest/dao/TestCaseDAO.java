package com.codequest.dao;

import com.codequest.config.DatabaseConfig;
import com.codequest.model.TestCase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TestCaseDAO {
    private final DatabaseConfig dbConfig;

    public TestCaseDAO() {
        this.dbConfig = DatabaseConfig.getInstance();
    }

    public List<TestCase> getTestCasesForQuestion(int questionId) throws SQLException {
        List<TestCase> testCases = new ArrayList<>();
        String sql = "SELECT * FROM test_cases WHERE question_id = ?";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                testCases.add(new TestCase(
                    rs.getInt("id"),
                    rs.getInt("question_id"),
                    rs.getString("input"),
                    rs.getString("expected_output")
                ));
            }
        }
        return testCases;
    }

    public void addTestCase(TestCase testCase) throws SQLException {
        String sql = "INSERT INTO test_cases (question_id, input, expected_output) VALUES (?, ?, ?)";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, testCase.getQuestionId());
            pstmt.setString(2, testCase.getInput());
            pstmt.setString(3, testCase.getExpectedOutput());
            pstmt.executeUpdate();
        }
    }
}
