package com.codequest.dao;

import com.codequest.config.DatabaseConfig;
import com.codequest.model.ChallengeRoom;
import com.codequest.model.RoomParticipant;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ChallengeRoomDAO {
    private final DatabaseConfig dbConfig;

    public ChallengeRoomDAO() {
        this.dbConfig = DatabaseConfig.getInstance();
    }

 

	 public ChallengeRoom createRoom(String name, int creatorId, int questionId, LocalDateTime startTime, int maxParticipants) throws SQLException {
	     String createRoomSql = "INSERT INTO challenge_rooms (name, creator_id, question_id, start_time, status, max_participants) " +
	                           "VALUES (?, ?, ?, ?, 'WAITING', ?)";
	     
	     Connection conn = null;
	     try {
	         conn = dbConfig.getConnection();
	         conn.setAutoCommit(false); 
	         
	         // Create the room
	         PreparedStatement pstmt = conn.prepareStatement(createRoomSql, Statement.RETURN_GENERATED_KEYS);
	         pstmt.setString(1, name);
	         pstmt.setInt(2, creatorId);
	         pstmt.setInt(3, questionId);
	         pstmt.setTimestamp(4, Timestamp.valueOf(startTime));
	         pstmt.setInt(5, maxParticipants);
	         
	         pstmt.executeUpdate();
	         
	         ResultSet rs = pstmt.getGeneratedKeys();
	         if (rs.next()) {
	             int roomId = rs.getInt(1);
	             
	             // Add creator as participant
	             String addParticipantSql = "INSERT INTO room_participants (room_id, user_id, join_time) VALUES (?, ?, ?)";
	             PreparedStatement participantStmt = conn.prepareStatement(addParticipantSql);
	             participantStmt.setInt(1, roomId);
	             participantStmt.setInt(2, creatorId);
	             participantStmt.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
	             participantStmt.executeUpdate();
	             
	             conn.commit(); 
	             
	             return new ChallengeRoom(roomId, name, creatorId, questionId, startTime, null, "WAITING", maxParticipants);
	         }
	         throw new SQLException("Failed to create challenge room");
	     } catch (SQLException e) {
	         if (conn != null) {
	             try {
	                 conn.rollback();
	             } catch (SQLException ex) {
	                 ex.printStackTrace();
	             }
	         }
	         throw e;
	     } finally {
	         if (conn != null) {
	             try {
	                 conn.setAutoCommit(true);
	                 conn.close();
	             } catch (SQLException e) {
	                 e.printStackTrace();
	             }
	         }
	     }
	 }
    public List<ChallengeRoom> getActiveRooms() throws SQLException {
        List<ChallengeRoom> rooms = new ArrayList<>();
        String sql = "SELECT * FROM challenge_rooms WHERE status != 'COMPLETED' ORDER BY start_time DESC";

        try (Connection conn = dbConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                ChallengeRoom room = extractRoomFromResultSet(rs);
                rooms.add(room);
            }
        }
        return rooms;
    }

    private ChallengeRoom extractRoomFromResultSet(ResultSet rs) throws SQLException {
        return new ChallengeRoom(
            rs.getInt("id"),
            rs.getString("name"),
            rs.getInt("creator_id"),
            rs.getInt("question_id"),
            rs.getTimestamp("start_time").toLocalDateTime(),
            rs.getTimestamp("end_time") != null ? rs.getTimestamp("end_time").toLocalDateTime() : null,
            rs.getString("status"),
            rs.getInt("max_participants")
        );
    }

    public void addParticipant(int roomId, int userId) throws SQLException {
        String sql = "INSERT INTO room_participants (room_id, user_id) VALUES (?, ?)";
        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, roomId);
            pstmt.setInt(2, userId);
            pstmt.executeUpdate();
        }
    }

    
 

    


	 public void updateParticipantScore(int roomId, int userId, int score) throws SQLException {
	     String sql = "UPDATE room_participants SET score = ? WHERE room_id = ? AND user_id = ?";
	     
	     try (Connection conn = dbConfig.getConnection();
	          PreparedStatement pstmt = conn.prepareStatement(sql)) {
	         
	         pstmt.setInt(1, score);
	         pstmt.setInt(2, roomId);
	         pstmt.setInt(3, userId);
	         
	         pstmt.executeUpdate();
	     }
	 }
	 
	

	public void endChallenge(int roomId) throws SQLException {
	    String sql = "UPDATE challenge_rooms SET status = 'COMPLETED', end_time = ? WHERE id = ?";
	    
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
	        pstmt.setInt(2, roomId);
	        pstmt.executeUpdate();
	    }
	}

	public void removeParticipant(int roomId, int userId) throws SQLException {
	    String sql = "DELETE FROM room_participants WHERE room_id = ? AND user_id = ?";
	    
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setInt(1, roomId);
	        pstmt.setInt(2, userId);
	        pstmt.executeUpdate();
	    }
	}

	public boolean isRoomActive(int roomId) throws SQLException {
	    String sql = "SELECT status FROM challenge_rooms WHERE id = ?";
	    
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setInt(1, roomId);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            String status = rs.getString("status");
	            return !status.equals("COMPLETED");
	        }
	        return false;
	    }
	}
	

	public void updateParticipantStatus(int roomId, int userId, String status) throws SQLException {
	    String sql = "UPDATE room_participants SET status = ? WHERE room_id = ? AND user_id = ?";
	    
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setString(1, status);
	        pstmt.setInt(2, roomId);
	        pstmt.setInt(3, userId);
	        
	        pstmt.executeUpdate();
	    }
	}

	public List<RoomParticipant> getRoomParticipants(int roomId) throws SQLException {
	    List<RoomParticipant> participants = new ArrayList<>();
	    String sql = "SELECT rp.*, u.username, rs.status " +
	             "FROM room_participants rp " +
	             "JOIN users u ON rp.user_id = u.id " +
	             "LEFT JOIN ( " +
	             "    SELECT user_id, MAX(submission_time) as latest_time, status " +
	             "    FROM room_submissions " +
	             "    WHERE room_id = ? " +
	             "    GROUP BY user_id " +
	             ") rs ON rs.user_id = rp.user_id " +
	             "WHERE rp.room_id = ?";

	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setInt(1, roomId);
	        pstmt.setInt(2, roomId);
	        ResultSet rs = pstmt.executeQuery();

	        while (rs.next()) {
	            RoomParticipant participant = new RoomParticipant(
	                rs.getInt("room_id"),
	                rs.getInt("user_id"),
	                rs.getString("username"),
	                rs.getTimestamp("join_time").toLocalDateTime(),
	                rs.getTimestamp("completed_at") != null ? 
	                    rs.getTimestamp("completed_at").toLocalDateTime() : null,
	                rs.getInt("score")
	            );
	            participant.setStatus(rs.getString("status") != null ? 
	                rs.getString("status") : "IN_PROGRESS");
	            participants.add(participant);
	        }
	    }
	    return participants;
	}

	
	public void submitSolution(int roomId, int userId, String code, String status) throws SQLException {
	    String sql = "INSERT INTO room_submissions (room_id, user_id, code, status) VALUES (?, ?, ?, ?)";
	    
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setInt(1, roomId);
	        pstmt.setInt(2, userId);
	        pstmt.setString(3, code);
	        pstmt.setString(4, status);
	        
	        pstmt.executeUpdate();
	        
	        // Update participant status
	        if (status.equals("ACCEPTED")) {
	            updateParticipantStatus(roomId, userId, "COMPLETED");
	        }
	    }
	}
	public void updateRoomStatus(ChallengeRoom room) throws SQLException {
	    String sql = "UPDATE challenge_rooms SET status = ?, start_time = ? WHERE id = ?";
	    
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setString(1, room.getStatus());
	        pstmt.setTimestamp(2, room.getStartTime() != null ? 
	            Timestamp.valueOf(room.getStartTime()) : null);
	        pstmt.setInt(3, room.getId());
	        
	        pstmt.executeUpdate();
	    }
	}

	public ChallengeRoom getRoom(int roomId) throws SQLException {
	    String sql = "SELECT * FROM challenge_rooms WHERE id = ?";
	    
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setInt(1, roomId);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            ChallengeRoom room = new ChallengeRoom(
	                rs.getInt("id"),
	                rs.getString("name"),
	                rs.getInt("creator_id"),
	                rs.getInt("question_id"),
	                rs.getTimestamp("start_time") != null ? 
	                    rs.getTimestamp("start_time").toLocalDateTime() : null,
	                rs.getTimestamp("end_time") != null ? 
	                    rs.getTimestamp("end_time").toLocalDateTime() : null,
	                rs.getString("status"),
	                rs.getInt("max_participants")
	            );
	            room.setDuration(rs.getInt("duration"));
	            return room;
	        }
	        return null;
	    }
	}
	// src/main/java/com/codequest/dao/ChallengeRoomDAO.java
	// Add these methods

	public List<ChallengeRoom> getUserCompletedRooms(int userId) throws SQLException {
		String sql = 
			    "SELECT cr.* FROM challenge_rooms cr " +
			    "JOIN room_participants rp ON cr.id = rp.room_id " +
			    "WHERE rp.user_id = ? AND cr.status = 'COMPLETED' " +
			    "ORDER BY cr.start_time DESC";

	    
	    List<ChallengeRoom> rooms = new ArrayList<>();
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setInt(1, userId);
	        ResultSet rs = pstmt.executeQuery();
	        
	        while (rs.next()) {
	            ChallengeRoom room = new ChallengeRoom(
	                rs.getInt("id"),
	                rs.getString("name"),
	                rs.getInt("creator_id"),
	                rs.getInt("question_id"),
	                rs.getTimestamp("start_time").toLocalDateTime(),
	                rs.getTimestamp("end_time") != null ? 
	                    rs.getTimestamp("end_time").toLocalDateTime() : null,
	                rs.getString("status"),
	                rs.getInt("max_participants")
	            );
	            rooms.add(room);
	        }
	    }
	    return rooms;
	}

	public int getUserScore(int roomId, int userId) throws SQLException {
	    String sql = "SELECT score FROM room_participants WHERE room_id = ? AND user_id = ?";
	    
	    try (Connection conn = dbConfig.getConnection();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {
	        
	        pstmt.setInt(1, roomId);
	        pstmt.setInt(2, userId);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getInt("score");
	        }
	    }
	    return 0;
	}

}