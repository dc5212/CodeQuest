package com.codequest.dao;

import com.codequest.config.DatabaseConfig;
import com.codequest.model.User;

import java.sql.*;
import java.util.Optional;

public class UserDAO {
    private final DatabaseConfig dbConfig;

    public UserDAO() {
        this.dbConfig = DatabaseConfig.getInstance();
    }
    public Optional<User> findById(int id) throws SQLException {
        String sql = "SELECT * FROM users WHERE id = ?";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                User user = new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("password")
                );
                user.setSolvedCount(rs.getInt("solved_count"));
                return Optional.of(user);
            }
        }
        return Optional.empty();
    }
    public Optional<User> findByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                User user = new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("password")
                );
                user.setSolvedCount(rs.getInt("solved_count"));
                return Optional.of(user);
            }
        }
        return Optional.empty();
    }

    public User createUser(String username, String password) throws SQLException {
        String sql = "INSERT INTO users (username, password, solved_count) VALUES (?, ?, 0)";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return new User(rs.getInt(1), username, password);
            }
            throw new SQLException("Failed to create user");
        }
    }

    public void incrementSolvedCount(int userId) throws SQLException {
        String sql = "UPDATE users SET solved_count = solved_count + 1 WHERE id = ?";

        try (Connection conn = dbConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, userId);
            pstmt.executeUpdate();
        }
    }
}